"use client"

import { FourthBentoAnimation } from "../src/components/fourth-bento-animation"

export default function SyntheticV0PageForDeployment() {
  return <FourthBentoAnimation />
}